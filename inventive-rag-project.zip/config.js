// config.js
// Replace the values below with your actual Supabase URL and Anon Key
// You can find these at: Supabase Dashboard → Project Settings → API
window.ENV = {
  SUPABASE_URL: "https://nguxauwhpyvezoyowmkl.supabase.co",
  SUPABASE_ANON: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5ndXhhdXdocHl2ZXpveW93bWtsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA4MzI3MDUsImV4cCI6MjA5NjQwODcwNX0.c56ktZ_hwKrBYG8oE9UwU0o3U4wJdaZhPzsxgEX_gNI",
  // Pinecone: set your index host and API key (host example: https://index-name-yourproj.svc.us-west1.pinecone.io)
  PINECONE_HOST: "",
  PINECONE_API_KEY: "",
  // OpenAI: API key for embeddings + generation
  OPENAI_API_KEY: "",
  // Optional: model overrides
  EMBEDDING_MODEL: "text-embedding-ada-002",
  GENERATION_MODEL: "gpt-4"
};
