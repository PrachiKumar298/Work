(function () {
  const HOST = window.ENV?.PINECONE_HOST || ""; // e.g. https://index-name-yourproj.svc.us-west1.pinecone.io
  const API_KEY = window.ENV?.PINECONE_API_KEY || "";

  function isConfigured() {
    return Boolean(HOST && API_KEY);
  }

  async function upsert(vectors, namespace) {
    if (!isConfigured()) return { data: null, error: "Pinecone not configured" };
    const url = `${HOST}/vectors/upsert`;
    const body = { vectors, namespace };
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Api-Key": API_KEY },
      body: JSON.stringify(body)
    });
    if (!res.ok) return { data: null, error: `Pinecone upsert failed: ${res.status}` };
    const data = await res.json();
    return { data, error: null };
  }

  async function query(vector, topK = 5, namespace) {
    if (!isConfigured()) return { data: null, error: "Pinecone not configured" };
    const url = `${HOST}/query`;
    const body = {
      vector,
      topK,
      includeMetadata: true,
      includeValues: false,
      namespace
    };
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Api-Key": API_KEY },
      body: JSON.stringify(body)
    });
    if (!res.ok) return { data: null, error: `Pinecone query failed: ${res.status}` };
    const data = await res.json();
    return { data, error: null };
  }

  window.PineconeClient = { isConfigured, upsert, query };
})();
