(function () {
  const OPENAI_KEY = window.ENV?.OPENAI_API_KEY || "";
  const MODEL = window.ENV?.EMBEDDING_MODEL || "text-embedding-ada-002";

  function isConfigured() {
    return Boolean(OPENAI_KEY);
  }

  async function embedText(text) {
    return embedTexts([text]).then((r) => (r?.[0] || null));
  }

  async function embedTexts(texts) {
    if (!isConfigured()) return null;
    const url = "https://api.openai.com/v1/embeddings";
    const body = { input: texts, model: MODEL };
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${OPENAI_KEY}` },
      body: JSON.stringify(body)
    });
    if (!res.ok) {
      const txt = await res.text();
      throw new Error(`OpenAI embed failed: ${res.status} ${txt}`);
    }
    const data = await res.json();
    return (data.data || []).map((d) => d.embedding || d.vector || null);
  }

  window.Embeddings = { isConfigured, embedText, embedTexts };
})();
