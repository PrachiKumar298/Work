(function () {
  const OPENAI_KEY = window.ENV?.OPENAI_API_KEY || "";
  const MODEL = window.ENV?.GENERATION_MODEL || "gpt-4";

  async function ingestChunksToPinecone(projectId, documentId, chunks) {
    if (!window.PineconeClient || !window.Embeddings) return { error: "Dependencies missing" };
    const texts = chunks.map((c) => c.content);
    const embeddings = await window.Embeddings.embedTexts(texts);
    if (!embeddings || !Array.isArray(embeddings)) {
      return { error: "Embeddings not available (check OPENAI_API_KEY)" };
    }
    const vectors = embeddings.map((vec, i) => ({
      id: `${documentId}-${i + 1}`,
      values: vec,
      metadata: {
        document_id: documentId,
        project_id: projectId,
        chunk_number: chunks[i].chunkNumber,
        source: chunks[i].source,
        content: chunks[i].content
      }
    }));
    const resp = await window.PineconeClient.upsert(vectors, projectId);
    return resp;
  }

  async function queryFiD(projectId, query, topK = 5) {
    if (!window.PineconeClient || !window.Embeddings) return { error: "Dependencies missing" };
    const qVec = await window.Embeddings.embedText(query);
    const { data, error } = await window.PineconeClient.query(qVec, topK, projectId);
    if (error) return { error };
    const matches = (data?.matches || []).map((m) => ({ id: m.id, score: m.score, metadata: m.metadata }));

    // Build FiD-style prompt: present each passage separately so the model can attend
    const passages = matches.map((m, idx) => ({
      id: m.id,
      text: m.metadata?.content || "",
      source: m.metadata?.document_id || m.metadata?.source || ""
    }));

    const answer = await generateWithFiD(query, passages);
    return { answer, matches };
  }

  async function generateWithFiD(query, passages) {
    if (!OPENAI_KEY) throw new Error("OpenAI key not configured");

    // Compose a user prompt that lists each passage with an index.
    let prompt = "You are an assistant that must answer the question using the provided passages. Cite passages by their index in square brackets, e.g. [1].\n\n";
    prompt += `Question: ${query}\n\nPassages:\n`;
    passages.forEach((p, i) => {
      prompt += `[#${i + 1}] ${p.text}\n\n`;
    });
    prompt += "\nWrite a concise, factual answer and include a 'Citations' section listing the passage indexes you used with their document ids.\n";

    const url = "https://api.openai.com/v1/chat/completions";
    const body = {
      model: MODEL,
      messages: [
        { role: "system", content: "You are a helpful assistant that must ground answers in provided passages." },
        { role: "user", content: prompt }
      ],
      max_tokens: 512,
      temperature: 0.0
    };

    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${OPENAI_KEY}` },
      body: JSON.stringify(body)
    });
    if (!res.ok) {
      const txt = await res.text();
      throw new Error(`OpenAI generate failed: ${res.status} ${txt}`);
    }
    const data = await res.json();
    const text = data.choices?.[0]?.message?.content || "";
    return { text, raw: data };
  }

  window.FidEngine = { ingestChunksToPinecone, queryFiD, generateWithFiD };
})();
